"""Download the lab's fixed model snapshot, then verify a local-only reload.

Run once on a machine with internet access:
    python -m pip install -r requirements-model.txt
    python prepare_model.py
"""
from pathlib import Path
import json
import sys
from importlib.metadata import version

MODEL_ID = 'sentence-transformers/all-MiniLM-L6-v2'
REVISION = '1110a243fdf4706b3f48f1d95db1a4f5529b4d41'
DEST = Path(__file__).resolve().parent / 'models' / 'all-MiniLM-L6-v2'


def main():
    try:
        import numpy as np
        from sentence_transformers import SentenceTransformer
    except ImportError as exc:
        raise SystemExit('Install requirements-model.txt before running this script.') from exc
    print('Preparing:',MODEL_ID,'\nRevision:',REVISION)
    model = SentenceTransformer(MODEL_ID, revision=REVISION, device='cpu')
    DEST.parent.mkdir(exist_ok=True)
    model.save(str(DEST))
    local = SentenceTransformer(str(DEST), device='cpu', local_files_only=True)
    X=local.encode(['The same sentence.','The same sentence.'], convert_to_numpy=True,
                   show_progress_bar=False, normalize_embeddings=False)
    if X.shape != (2,384) or not np.isfinite(X).all() or not np.allclose(X[0],X[1],atol=1e-6):
        raise RuntimeError('The local model failed its shape, finite-value, or repeatability check.')
    record={'model_id':MODEL_ID,'revision':REVISION,'embedding_width':384,
            'max_sequence_length':int(local.max_seq_length),
            'versions':{name:version(name) for name in ['sentence-transformers','transformers','torch','numpy']}}
    (DEST.parent/'model_manifest.json').write_text(json.dumps(record,indent=2),encoding='utf-8')
    print('Local-only reload and identical-text check passed.')
    print('Now restart the notebook kernel and Run All.')


if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, ValueError) as exc:
        print(f'Model preparation failed: {exc}',file=sys.stderr)
        sys.exit(1)
