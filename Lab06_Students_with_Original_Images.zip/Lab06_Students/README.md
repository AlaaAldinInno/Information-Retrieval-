# Lab 06 · Vector Space Model

## Students edition

This lab follows the supplied Vector Space Model notebook: represent food items with
numeric features, inspect their geometry, reduce dimension with PCA and SVD, normalize
rows, and retrieve similar items with cosine similarity. Query projection and
neighborhood comparison extend the original workflow. This is not a nutrition-advice lab.

The student notebook contains nine guided programming exercises. Before each code gap,
read the contract, numbered section explanation, pseudocode, worked example or sanity
check, and API hints. Five written-response cells are included, one in the optional
extension. Teacher-only solutions and discussion answers are not included.

## Files

- `Lab06_Students.ipynb`: editable student workbook.
- `Lab06_Students.html`: offline reading copy; it does not execute Python.
- `lab06_support.py`: input validation, plotting, display, and exercise checks.
- `data/nutrition.csv` and `data/README.md`: original source snapshot and its provenance.
- `requirements.txt` and `VALIDATION.md`: setup dependencies and verification record.

## Setup

Extract the entire ZIP. Keep the notebook, helper module, and `data` folder together.
Use Python 3.11 or later; the exact version used for verification is in `VALIDATION.md`.
In a terminal opened in this folder, install dependencies and start JupyterLab:

```bash
python -m pip install -r requirements.txt
python -m jupyter lab
```

Select this folder's notebook and a Python kernel with those packages installed.
An internet connection is needed for package installation unless your environment already
has the dependencies. After installation, every required notebook cell runs with local
data and no network request. No account, credential, or API key is required.

The HTML file can be opened directly in a browser without Jupyter or an internet
connection. It is a static reading copy with embedded equations and saved outputs;
editing the notebook does not automatically update the HTML.

## Working through the notebook

Run cells from top to bottom. The nine exercises build on one another:

| Exercise | Task |
|---|---|
| E1 | Prepare aligned food vectors and metadata |
| E2 | Fit PCA and obtain reduced coordinates |
| E3 | Measure PCA retention and reconstruction |
| E4 | Build and inspect a truncated SVD representation |
| E5 | Normalize rows safely |
| E6 | Compute cosine scores |
| E7 | Return deterministic top-k neighbors |
| E8 | Project a new query with the fitted model |
| E9 | Measure neighbor-set overlap |

Each exercise has a check cell. `PASS` means its checks succeeded; `INCOMPLETE` identifies
an unimplemented gap; `FAIL` identifies a contract violation. Demonstrations report
`BLOCKED` when earlier exercises are not ready. After changing code, rerun the function
definition, its check, and any dependent cells. Finish with a fresh-kernel Run All.

The provided helper does not contain reference implementations for the nine exercises.
It supplies infrastructure and visible checks. Follow the documented zero-vector,
self-exclusion, and tie-breaking policies; they are part of the task, not incidental details.

## Teaching and data boundaries

The baseline intentionally reproduces the original table's zero-filling policy. Missing
values are not claimed to be measured zeros. Original unit labels and serving descriptions
are retained. Review `data/README.md` before interpreting any food comparison.

PCA centers but does not automatically standardize features. Truncated SVD does not
guarantee preservation of every cosine or nearest neighbor. Reconstruction retention,
neighbor overlap, and relevance quality answer different questions. The notebook provides
worked counterexamples and discussion prompts for these distinctions.



## Original recommendation photographs
The package includes `data/nutr_img/`, copied from the supplied original image archive. The recommendation section uses these `.jpg` files for display only. Similarity is calculated from `data/nutrition.csv`; the photographs are not model inputs.
