# Validation record

## Executed and verified

The teacher notebook was executed from a fresh Python kernel in its package directory. Its ten programming contract checks pass. The untouched student notebook executes without uncaught exceptions and deliberately reports INCOMPLETE/BLOCKED for its gaps. A separate, temporary student copy completed with reference implementations passes all ten checks; a completed judgment worksheet in that temporary copy also exercises the evaluation and plotting path. Reference solutions and completed judgments were not placed in the distributed student workbook.

The teacher numerical validator passes **1,871 independent assertions**, including **160 random matrix cases**, **180 random metric cases**, scale/zero/extreme-magnitude normalization checks, source-result identity checks, and baseline/evaluation checks. Cosines are compared with SciPy; exponential-gain DCG/nDCG are compared with scikit-learn after applying the declared gain transformation. Strict library ranking scores avoid a mismatch between deterministic ordering and library tie averaging.

The corpus's 13,160 raw bytes match the original repository's Git blob SHA. All 35 archived query-bucket texts match their row IDs in that corpus. Neither archived scores nor embeddings are fabricated.

## Not executed in this environment

The pretrained checkpoint could not be downloaded: the runtime had no usable external network connection, no cached weights, and no installed Sentence Transformers package. Therefore fresh neural embeddings, current-model semantic rankings, and the live query-similarity heatmap were **not executed**. The notebook reports PREPARATION REQUIRED for those cells. `prepare_model.py` is supplied for a one-time download and local-only smoke check on a connected machine. The model requirements are an API-compatible specification, not a claimed tested installation in this runtime.

Encoder unit checks use the small explicitly named `UnitTestEncoder` fixture. These verify interface, shape, batching, row alignment and pipeline behavior. They are not language-understanding tests, do not produce the archived results, and are not used to report model quality.

## Rendering

The HTML reading copies pre-render equations as embedded SVG and contain embedded plot images. They do not require an internet connection to display mathematics or recorded outputs. Code in an HTML copy is read-only. See `render_validation.json` for the desktop/mobile checks and inspected layout counts.

## Tested numerical environment

Python 3.13.5; NumPy 2.3.5; pandas 2.2.3; scikit-learn 1.8.0; Matplotlib 3.10.8. Kernel execution used nbclient 0.10.4 and notebook format validation used nbformat 5.10.4. The supplied numerical requirements reflect tested versions. A fresh-kernel run without the pretrained model is not a complete semantic-inference verification.
