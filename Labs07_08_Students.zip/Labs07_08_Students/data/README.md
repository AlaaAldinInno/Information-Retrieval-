# Data and provenance

`facts.txt` is the original IUCVLab Information Retrieval curious-facts corpus. It contains 159 nonblank lines. The raw UTF-8 bytes match Git blob `1651fedcbcfaed7c4692764b7eb3d01d160c51d0`. `manifest.json` records the SHA-256 and source-notebook digests. No generated replacement corpus is used.

The printed numbers are part of the text and are not unique. Every programmatic `doc_id` in this package is the zero-based row position in this snapshot. Preserve row order; changing the corpus requires rebuilding vectors, runs and judgments.

`queries.json` contains the seven source queries, unchanged. `archived_run.json` stores the 35 results from the uploaded solution's query-bucket output in its displayed order. `original_saved_outputs.txt` preserves ordinary text outputs from both uploaded notebooks. Download progress widgets are omitted. The archived scores are null because the source did not store numeric ranking scores.

`lexical_run.json` is a newly computed, explicitly labeled TF-IDF baseline from the same facts, not a neural run. The live baseline helper recomputes it; it is not used to simulate an encoder.

`intents.json` and `judgments_template.csv` are added instructional materials. The 47-pair initial judgment pool combines archived results, positive lexical results, and selected potentially relevant passages from the same corpus. Blank relevance cells mean unjudged. Complete a copy in `outputs/`; do not infer relevance from a similarity score. Relevance is query/document-specific, not an intrinsic property of a document.

Teacher-only `teaching_judgments.csv` contains suggested labels and reasons for the initial pool. These are editorial examples, not original labels, independently collected judgments, or a validated benchmark. The student package does not contain that file.

## Corpus caution

These historical passages include outdated, unverified and sensitive claims. They are reproduced only as retrieval data. A relevance judgment does not endorse the truth or safety of the statement. The package makes no factual, medical, legal or demographic claims based on this corpus.
