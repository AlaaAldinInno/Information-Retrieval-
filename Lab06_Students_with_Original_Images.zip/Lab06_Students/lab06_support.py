"""Input validation, display helpers, and small checks for Lab 06.

Exercise implementations belong in the notebook, not in this module.
"""
from pathlib import Path
from numbers import Integral
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import display

DATA = Path(__file__).resolve().parent / 'data'
CHECKS = {f'E{i}': 'NOT RUN' for i in range(1, 10)}


def as_matrix(A):
    """Return an independent, finite, real, two-dimensional float array."""
    if np.iscomplexobj(A):
        raise ValueError('Use real-valued features.')
    X = np.array(A, dtype=float, copy=True)
    if X.ndim != 2 or X.shape[1] == 0:
        raise ValueError('Expected a matrix with at least one feature column.')
    if not np.isfinite(X).all():
        raise ValueError('Resolve missing and non-finite values before this step.')
    return X


def as_query(query, width):
    if np.iscomplexobj(query):
        raise ValueError('Use a real-valued query.')
    q = np.array(query, dtype=float, copy=True)
    if q.ndim != 1 or q.size != width or not np.isfinite(q).all():
        raise ValueError(f'Expected a finite query vector of shape ({width},).')
    return q


def validate_components(A, n_components, centered=False):
    X = as_matrix(A)
    if isinstance(n_components, bool) or not isinstance(n_components, Integral):
        raise ValueError('n_components must be an integer.')
    if not 1 <= n_components <= min(X.shape):
        raise ValueError('n_components must be between 1 and min(A.shape).')
    if centered and (X.shape[0] < 2 or not np.any(X != X[0])):
        raise ValueError('PCA needs at least two rows and nonzero centered variance.')
    if not centered and not np.any(X):
        raise ValueError('SVD energy ratios need a nonzero input matrix.')
    return X


def validate_top_k(k, exclude, n_rows):
    if isinstance(k, bool) or not isinstance(k, Integral) or k < 0:
        raise ValueError('k must be a nonnegative integer.')
    if exclude is not None:
        if (isinstance(exclude, bool) or not isinstance(exclude, Integral)
                or not 0 <= exclude < n_rows):
            raise ValueError('exclude must be a valid row ID or None.')


def run_check(key, check):
    """Report unfinished work separately from an incorrect implementation."""
    try:
        check()
    except NotImplementedError:
        CHECKS[key] = 'INCOMPLETE'
        print(f'{key}: INCOMPLETE — fill the exercise block, then run this check again.')
    except Exception as exc:
        CHECKS[key] = 'FAIL'
        print(f'{key}: FAIL — {type(exc).__name__}: {exc}')
    else:
        CHECKS[key] = 'PASS'
        print(f'{key}: PASS')
    return CHECKS[key] == 'PASS'


def ready(*keys):
    missing = [k for k in keys if CHECKS.get(k) != 'PASS']
    if missing:
        print('BLOCKED — first complete and check: ' + ', '.join(missing))
        return False
    return True


def show_progress():
    display(pd.DataFrame({'exercise': list(CHECKS), 'status': list(CHECKS.values())}))


def _raises(fn, exception=ValueError):
    try:
        fn()
    except exception:
        return
    raise AssertionError(f'Expected {exception.__name__}.')


def check_prepare(fn):
    raw = pd.DataFrame({
        'Food and Serving': [None, 'Alpha, small', 'Beta, large'],
        'Calories': [None, '20', '40'], 'Protein': ['(g)', '2', None],
        'Food Type': [None, 'Group A', 'Group B']})
    before = raw.copy(deep=True)
    A, names, labels, features, missing = fn(raw)
    np.testing.assert_allclose(A, [[20., 2.], [40., 0.]])
    assert A.dtype.kind == 'f', 'Convert the matrix to floating-point numbers.'
    assert list(names) == ['Alpha', 'Beta'], 'Keep names in the same order as rows.'
    assert list(labels) == ['Group A', 'Group B']
    assert list(features) == ['Calories', 'Protein']
    assert missing.to_dict() == {'Calories': 0, 'Protein': 1}
    pd.testing.assert_frame_equal(raw, before)
    bad = raw.copy(); bad.loc[1, 'Calories'] = 'unknown'
    _raises(lambda: fn(bad))


def check_pca(fn):
    A = np.array([[1., 0.], [2., 0.], [3., 0.]])
    before = A.copy()
    model, Z = fn(A, n_components=1)
    assert Z.shape == (3, 1)
    np.testing.assert_allclose(model.mean_, [2., 0.])
    np.testing.assert_allclose(Z.mean(axis=0), 0., atol=1e-12)
    np.testing.assert_allclose(model.inverse_transform(Z), A, atol=1e-12)
    np.testing.assert_allclose(model.explained_variance_ratio_.sum(), 1.)
    np.testing.assert_allclose(A, before)
    assert not model.whiten, 'Do not whiten in the main comparison.'
    _raises(lambda: fn(A, n_components=0))
    _raises(lambda: fn(np.ones((3, 2)), n_components=1))


def check_pca_diagnostics(fn):
    from sklearn.decomposition import PCA
    A = np.array([[2., 0.], [-2., 0.], [0., 1.], [0., -1.]])
    pca = PCA(n_components=1, svd_solver='full').fit(A)
    out = fn(A, pca, pca.transform(A))
    assert set(out) == {'retained_variance', 'relative_centered_error'}
    np.testing.assert_allclose(out['retained_variance'], .8)
    np.testing.assert_allclose(out['relative_centered_error'], np.sqrt(.2))


def check_svd(fn):
    A = np.diag([4., 3., 1.])
    before = A.copy()
    model = fn(A, n_components=2)
    assert set(model) == {'Z', 'basis', 'singular_values', 'retained_energy', 'relative_error'}
    assert model['Z'].shape == (3, 2) and model['basis'].shape == (2, 3)
    np.testing.assert_allclose(model['Z'], A @ model['basis'].T, atol=1e-12)
    np.testing.assert_allclose(model['Z'] @ model['basis'], np.diag([4., 3., 0.]), atol=1e-12)
    np.testing.assert_allclose(model['singular_values'], [4., 3., 1.])
    np.testing.assert_allclose(model['retained_energy'], 25/26)
    np.testing.assert_allclose(model['relative_error'], 1/np.sqrt(26))
    np.testing.assert_allclose(A, before)
    _raises(lambda: fn(A, 4)); _raises(lambda: fn(np.zeros((3, 2)), 1))


def check_norm(fn):
    A = np.array([[3, 4], [0, 0], [-3, 4]])
    before = A.copy()
    np.testing.assert_allclose(fn(A), [[.6, .8], [0, 0], [-.6, .8]], atol=1e-12)
    np.testing.assert_allclose(A, before)
    assert fn(np.empty((0, 2))).shape == (0, 2)
    _raises(lambda: fn([[float('nan'), 1.]]))


def check_cosine(fn):
    q = np.array([3., 4.]); A = np.array([[6., 8.], [4., -3.], [0., 0.]])
    np.testing.assert_allclose(fn(q, A), [1., 0., 0.], atol=1e-12)
    np.testing.assert_allclose(fn(q*5, A*2), fn(q, A), atol=1e-12)
    np.testing.assert_allclose(fn([0., 0.], A), [0., 0., 0.])
    assert fn(q, np.empty((0, 2))).shape == (0,)
    _raises(lambda: fn([1., 2., 3.], A))


def check_closest(fn):
    A = np.array([[1., 0.], [2., 0.], [0., 1.], [0., 0.], [-1., 0.]])
    assert list(fn(A[0], A, k=2, exclude=0)) == [1, 2], 'Exclude self before selecting k.'
    assert list(fn(A[0], A, k=10, exclude=0)) == [1, 2, 4], 'Skip zero rows, not negative scores.'
    assert list(fn(A[0], A, k=2)) == [0, 1], 'Resolve equal scores by ascending row ID.'
    assert list(fn(A[0], A, k=0)) == []
    assert list(fn([0., 0.], A, k=2)) == []
    assert list(fn(A[0], np.empty((0, 2)), k=2)) == []
    _raises(lambda: fn(A[0], A, k=-1))
    _raises(lambda: fn(A[0], A, k=1.2))
    _raises(lambda: fn(A[0], A, exclude=len(A)))


def check_project(fn):
    from sklearn.decomposition import PCA
    A = np.array([[1., 2.], [3., 1.], [4., 5.]])
    pca = PCA(n_components=1, svd_solver='full').fit(A)
    mean_before = pca.mean_.copy()
    np.testing.assert_allclose(fn(A[1], 'pca', pca), pca.transform(A[1:2])[0])
    np.testing.assert_allclose(pca.mean_, mean_before)
    U, s, Vt = np.linalg.svd(A, full_matrices=False)
    model = {'basis': Vt[:1]}
    np.testing.assert_allclose(fn(A[1], 'svd', model), A[1] @ Vt[:1].T)
    _raises(lambda: fn(A[1], 'unknown', model))
    _raises(lambda: fn([1., 2., 3.], 'pca', pca))


def check_overlap(fn):
    np.testing.assert_allclose(fn([2, 5, 7], [5, 7, 9]), 2/3)
    assert fn([2, 5, 7], [7, 5, 2]) == 1.0, 'This measure ignores order.'
    assert fn([2, 5, 7], [1, 8, 9]) == 0.0
    assert fn([2, 5, 7], []) == 0.0
    _raises(lambda: fn([], []))
    _raises(lambda: fn([2, 2], [2]))
    _raises(lambda: fn([2], [2, 2]))


def table_rows(A, names, features, count=4):
    cols = [0, 2, 4, 6, 13] if len(features) >= 14 else list(range(len(features)))
    display(pd.DataFrame(A[:count, cols], columns=[features[j] for j in cols], index=names[:count]))


def plot_heatmap(A):
    fig, ax = plt.subplots(figsize=(9, 5))
    image = ax.imshow(A.T, aspect='auto')
    ax.set(xlabel='Food row ID', ylabel='Feature column ID', title='Raw teaching features: values are not unit-comparable')
    fig.colorbar(image, ax=ax, label='Recorded numeric value')
    fig.tight_layout(); plt.show()


def plot_embedding(Z, names, labels, title, axes=('Component 1', 'Component 2'), annotate=()):
    fig, ax = plt.subplots(figsize=(8, 5))
    for label in sorted(set(labels)):
        ids = np.flatnonzero(np.asarray(labels) == label)
        ax.scatter(Z[ids, 0], Z[ids, 1], label=str(label).split(',')[0].split(' Serving')[0], s=36)
    for i in annotate:
        ax.annotate(names[i], (Z[i, 0], Z[i, 1]), xytext=(4, 5), textcoords='offset points', fontsize=9)
    ax.set(xlabel=axes[0], ylabel=axes[1], title=title)
    ax.legend(); fig.tight_layout(); plt.show()


def plot_3d(Z, labels, title):
    fig = plt.figure(figsize=(8, 6)); ax = fig.add_subplot(111, projection='3d')
    for label in sorted(set(labels)):
        ids = np.flatnonzero(np.asarray(labels) == label)
        ax.scatter(Z[ids, 0], Z[ids, 1], Z[ids, 2], label=str(label).split(',')[0].split(' Serving')[0])
    ax.set(xlabel='Component 1', ylabel='Component 2', zlabel='Component 3', title=title)
    ax.legend(loc='upper left'); fig.tight_layout(); plt.show()


def results_table(ids, scores, names):
    return pd.DataFrame({'rank': range(1, len(ids)+1), 'row_id': ids,
                         'food': [names[i] for i in ids], 'cosine': [float(scores[i]) for i in ids]})
