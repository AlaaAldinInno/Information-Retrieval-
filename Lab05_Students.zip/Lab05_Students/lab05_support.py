"""Data loading, notebook checks, and display utilities for Lab 05.

Exercise implementations belong in the notebook, not in this module.
All required activities run without network access.
"""
from pathlib import Path
import csv
import gzip
import hashlib
import html
import json
import re
from IPython.display import HTML, display

WORD_RE = re.compile(r"\b[A-Za-z]+\b")

def sent_to_words(text):
    """Return lowercase, whole ASCII-alphabetic tokens; do not stem."""
    if not isinstance(text, str):
        raise TypeError("text must be a string")
    return [m.group(0).lower() for m in WORD_RE.finditer(text)]

def normalize_word(word):
    """Normalize one ASCII word; the empty string is allowed as a sentinel."""
    if not isinstance(word, str):
        raise TypeError("word must be a string")
    word = word.lower()
    if word and re.fullmatch(r"[a-z]+", word) is None:
        raise ValueError("Use one word containing only the letters a-z.")
    return word

def load_lines(path):
    return [line.strip() for line in Path(path).read_text(encoding="utf-8").splitlines()
            if line.strip() and not line.startswith("#")]

def load_word_pairs(path):
    with Path(path).open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    for row in rows:
        normalize_word(row["source"])
        normalize_word(row["target"])
        if not row["source"] or row["source"] == row["target"]:
            raise ValueError("Typo rows must contain two different, nonempty words.")
    return rows

class LabChecks:
    """Record completed, unfinished, failed, and dependency-blocked exercises."""
    def __init__(self):
        self.results = {}

    def ready(self, requirements):
        return all(self.results.get(key) == "PASS" for key in requirements)

    def check(self, key, test, requires=()):
        missing = [x for x in requires if self.results.get(x) != "PASS"]
        if missing:
            self.results[key] = "BLOCKED"
            print(f"{key}: BLOCKED — complete {', '.join(missing)} first.")
            return
        try:
            test()
        except NotImplementedError as exc:
            self.results[key] = "INCOMPLETE"
            print(f"{key}: INCOMPLETE — {exc}")
        except AssertionError as exc:
            self.results[key] = "FAIL"
            print(f"{key}: FAIL — {exc or 'An assertion did not hold.'}")
        except Exception as exc:
            self.results[key] = "ERROR"
            print(f"{key}: ERROR — {type(exc).__name__}: {exc}")
        else:
            self.results[key] = "PASS"
            print(f"{key}: PASS")

    def demo(self, title, action, requires=()):
        if not self.ready(requires):
            print(f"{title}: available after {', '.join(requires)} pass.")
            return
        action()

    def summary(self):
        show_table(["Check", "Status"], self.results.items())
        passed = sum(value == "PASS" for value in self.results.values())
        print(f"{passed}/{len(self.results)} checks passed.")
        if passed != len(self.results):
            print("Finish the incomplete exercises, then restart the kernel and run all cells.")

def show_table(headers, rows):
    """Render escaped HTML; no terminal escape codes or external assets."""
    heading = ''.join(f"<th>{html.escape(str(x))}</th>" for x in headers)
    body = ''.join('<tr>' + ''.join(f"<td>{html.escape(str(x))}</td>" for x in row)
                   + '</tr>' for row in rows)
    display(HTML(f'<table><thead><tr>{heading}</tr></thead><tbody>{body}</tbody></table>'))

def restore_case(original, replacement):
    if original.isupper():
        return replacement.upper()
    if original.istitle():
        return replacement.capitalize()
    return replacement

def iter_github_edits(path, limit=None):
    """Stream English typo edits from a local original-corpus JSONL or JSONL.GZ file.

    This reads the original schema; it does not download data or train a model.
    Missing/false typo labels are excluded. Invalid JSON identifies its line.
    """
    path = Path(path)
    if limit is not None and (not isinstance(limit, int) or isinstance(limit, bool) or limit < 0):
        raise ValueError("limit must be a nonnegative integer or None")
    if limit == 0:
        return
    opener = gzip.open if path.suffix == '.gz' else open
    count = 0
    with opener(path, 'rt', encoding='utf-8') as handle:
        for line_no, line in enumerate(handle, start=1):
            if not line.strip():
                continue
            try:
                obj = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON on line {line_no}") from exc
            for edit in obj.get('edits', []):
                src, tgt = edit.get('src', {}), edit.get('tgt', {})
                if src.get('lang') != 'eng' or tgt.get('lang') != 'eng':
                    continue
                if edit.get('is_typo') is not True:
                    continue
                before, after = src.get('text'), tgt.get('text')
                if not isinstance(before, str) or not isinstance(after, str):
                    continue
                if before.lower() == after.lower():
                    continue
                yield {'repo': obj.get('repo', ''), 'commit': obj.get('commit', ''),
                       'source': before, 'target': after}
                count += 1
                if limit is not None and count >= limit:
                    return

def repository_partition(repo):
    """Stable 80/10/10 hash-bucket rule; observed sizes need not match those ratios."""
    if not repo:
        raise ValueError("A repository identifier is required for grouped splitting.")
    bucket = int.from_bytes(hashlib.sha256(repo.encode('utf-8')).digest()[:8], 'big') % 10
    return 'train' if bucket < 8 else ('dev' if bucket == 8 else 'test')

def single_word_change(record):
    """Extract an aligned one-token replacement; this is not a grammar classifier."""
    before = sent_to_words(record['source'])
    after = sent_to_words(record['target'])
    if len(before) != len(after):
        return None
    changed = [i for i, (x, y) in enumerate(zip(before, after)) if x != y]
    if len(changed) != 1:
        return None
    i = changed[0]
    return before[i], after[i]
