# Validation record

## Executable notebooks

Both notebook files were validated against the Jupyter notebook format and executed
from fresh Python kernels using the package-local helper and CSV.

| Run | Exercise checks | Unhandled error outputs | Generated plots |
|---|---:|---:|---:|
| Teacher reference notebook | 9 PASS | 0 | 9 |
| Untouched student workbook | 9 INCOMPLETE | 0 | 0 |
| Separate completed copy of the student workbook | 9 PASS | 0 | 9 |

The completed student copy was used only for verification and is not distributed.
The untouched student notebook is expected to report `INCOMPLETE`; downstream demonstrations
report `BLOCKED` until their dependencies pass. These are explanatory status messages,
not hidden execution failures. When an implementation runs but violates its contract,
its check reports `FAIL` with diagnostic text.

## Independent numerical checks

A separate validator ran 1,287 comparisons, including 80 seeded random matrix cases.
All passed. It checks PCA through an independent covariance eigendecomposition; SVD
through Gram-matrix eigenvalues, reconstruction, and projection identities; row
normalization through scalar calculations; cosine against scikit-learn's reference;
and rankings against a separately computed score ordering. Query projection, overlap
calculations, invalid inputs, zero vectors, ties, self exclusion, and source-data
integrity are also covered by the independent checks or the exercise checks.

On the bundled table the three-component PCA retention is approximately 0.9092 and
its relative centered reconstruction error approximately 0.3013. The uncentered
three-component SVD energy retention is approximately 0.9778 and its relative
reconstruction error approximately 0.1490. These are representation diagnostics,
not accuracy figures for recommendations.

Small floating-point differences are expected across numerical libraries. Principal
component signs may also reverse without changing pairwise cosine within that
representation. The tests compare geometry, reconstructions, and tolerances rather
than demanding a particular sign convention.

## Rendering and layout

The reading copies contain 76 mathematical expressions each, rendered as inline SVG.
The teacher copy embeds all nine generated plots. No font or image files need to be
fetched from a server, and no external script is required to display the equations.
The equations remain editable LaTeX in the notebook's Markdown cells.

The HTML was rendered with Chromium in an offline browser context. Each notebook cell
was captured for visual inspection. Automated layout checks covered viewport widths
of 1,280 pixels and 390 pixels, including all equations, images, internal section links,
code blocks, and tables. No equation errors, unresolved math delimiters, broken internal
links, failed images, or page-level horizontal overflow were found. Four larger teacher
tables scroll within their own frames on the narrower viewport; this is intentional.

Source text and displayed results were visually reviewed in both editions. This tests
the supplied HTML and executed notebook content; it is not a claim that every browser,
operating system, or Jupyter theme was tested.

## Tested environment

Python 3.13.5 on Linux.

| Package | Version used |
|---|---|
| numpy | 2.3.5 |
| pandas | 2.2.3 |
| scipy | 1.17.0 |
| scikit-learn | 1.8.0 |
| matplotlib | 3.10.8 |
| nbformat | 5.10.4 |
| nbclient | 0.10.4 |
| ipykernel | 7.2.0 |

`requirements.txt` gives compatible installation ranges, not a guarantee that every
version within those ranges has been tested. Fresh installations may resolve differently.

## Scope

No judged relevance dataset is supplied. Neighborhood overlap is measured against a
specified vector-space baseline, not against human relevance judgments. The exercises
perform exact scans over the small catalog, not an approximate nearest-neighbor index.
The original data's unit and missing-value limitations remain explicitly documented.
