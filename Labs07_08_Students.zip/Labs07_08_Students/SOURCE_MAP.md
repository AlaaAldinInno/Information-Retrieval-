# Source map and documented changes

This package combines two substantially overlapping uploads into one workbook for Labs 07–08. It does not present them as two independent datasets or unrelated tasks.

| Supplied material | Revised location | Treatment |
|---|---|---|
| Shared introduction: sentence-vector search over curious facts | Opening and sections 1–2 | Same task and corpus; text classification is not invented because neither source implements a classifier. |
| 07 cells 1–4 / 08 cells 1–3: choose and load an embedding model | Preparation, E2–E3, prepare_model.py | Encoder choice retained. Direct Sentence Transformers with MiniLM replaces the older spaCy/RoBERTa wrapper; this is an explicit implementation change. |
| 07 cells 5–11 / 08 cells 4–7: embed arbitrary text; test width and distances | E2 and model demonstration | Adds strict shape/input tests; identical-text check retained. Unrelated-text similarity is an observation rather than a universal threshold. |
| 07 cells 12–14 / 08 cells 8–10: read facts | E1, moved before inference | Same facts.txt bytes; trim blank lines; protect stable row identity. |
| 07 cells 15–17 / 08 cells 11–13: document matrix | E3 | Adds batching, empty-input and row-alignment contracts. |
| 07 cells 18–21 / 08 cells 14–15: nearest documents | E4–E7 | Explicit cosine normalization, descending order, tie/zero policies. The original raw dot product is not relabeled as cosine. |
| 07 cells 22–23 / 08 cells 16–17: seven-query bucket | Result gallery and E7 | All original queries and saved results retained. |
| 07 DCG heading / 08 cells 18–19: own judgments and DCG | E8–E10 | Implements the unfinished evaluation activity and states the exact gain/discount conventions. |

## Added teaching material

Mathematical worked examples, student function contracts, pseudocode, checks, teacher notes, reflection prompts, an optional TF-IDF comparison, judgment templates, pool-relative nDCG and genuine data/metric plots are additions. The source does not supply gold relevance labels. The teacher's suggested judgments are editorial examples with rationales, not original labels or an independent benchmark.

## What the preserved results do and do not support

`data/archived_run.json` contains the exact displayed order from cell 23 of the uploaded 07 solution (zero-based cell numbering). All 35 texts match the bundled corpus by exact string comparison. The corresponding source code scores with a dot product. No numeric scores or embedding matrix were stored, so no scores or vectors have been reconstructed or invented.

The source's separate single-query result for “good mood” differs from its later query-bucket output. Both displays remain in `data/original_saved_outputs.txt`; the available source does not identify enough runtime state to reconcile them. The bucket archive is useful for studying relevance and order, but not as a fresh, reproducible neural run.

The default live checkpoint is `sentence-transformers/all-MiniLM-L6-v2`, revision `1110a243fdf4706b3f48f1d95db1a4f5529b4d41`. This differs from the source's `en_stsb_roberta_large` wrapper. Original stored results must not be attributed to MiniLM.

## No hidden data replacement

The exact original `facts.txt` snapshot is bundled, including repeated printed numbers and unverified claims. Zero-based row IDs identify passages. Corpus text has not been corrected or fact-checked; retrieval relevance is not factual endorsement. The unrelated nutrition data and photographs from Lab 06 are not used in this text-search exercise.
