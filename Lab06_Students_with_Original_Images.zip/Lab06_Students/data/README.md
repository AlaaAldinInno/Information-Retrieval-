# Source data for Lab 06

`nutrition.csv` is the original table referenced by the supplied
`06 - Vector Space Model solution.ipynb`, not a synthetic substitute.

Source repository: IUCVLab, *information-retrieval*.
Source path: `datasets/nutrition.csv` on the `main` branch.
Repository file: <https://github.com/IUCVLab/information-retrieval/blob/main/datasets/nutrition.csv>

The bundled bytes were checked against the repository Git blob:

```text
e4e1442e518f2b3b2095bde2cdf0b1f4c5e52788
```

SHA-256 of the bundled file:

```text
f1ad2bab2f046ac79f215bf2e91faee7f6e9c1a4493d28d7945cac55574e0712
```

The source uses carriage-return line endings. They have been retained; pandas reads them
without special configuration. A future copy fetched from `main` may differ, so use the
bundled snapshot for reproducible exercises.

## Layout

The header has 24 columns. The first data row contains unit annotations, not a food.
After excluding that row, there are 61 food items and 22 numeric feature columns,
plus the `Food and Serving` and `Food Type` metadata columns. The collection contains
20 vegetable rows, 20 fruit rows, and 21 seafood rows. Keep this row order when mapping
vectors back to names.

The numeric block contains 223 blank cells before imputation:

| Column | Blank cells |
|---|---:|
| Dietary Fiber 1 | 21 |
| Dietary Fiber 2 | 21 |
| Sugars | 21 |
| Saturated Fat | 40 |
| Saturated Fat 2 | 40 |
| Chole-sterol 1 | 40 |
| Chole-sterol 2 | 40 |

## Reproduction policy and limitations

The main baseline retains the original 22 feature columns, converts them to numbers,
and fills blanks with zero, following the original notebook's input construction.
This is an explicit modeling assumption. A blank cell is not evidence that the nutrient
is absent. The exercise records missingness before filling it, and the raw CSV is unchanged.
Unexpected nonnumeric feature values must raise an error rather than silently become zero.

Some unit annotations are ambiguous or inconsistent, and the serving descriptions differ
between items. The lab does not silently correct labels or convert portions. It is a
teaching example for numerical representations, not a verified nutrition reference.
Cosine neighbors do not establish that foods are nutritionally interchangeable or suitable
for a person. No health or dietary recommendation is being made.

The optional standardization experiment changes feature weighting. It does not resolve
missing data, ambiguous units, or different portions.
