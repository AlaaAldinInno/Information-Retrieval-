# Lab 05 — Spell Checking and Tolerant Retrieval

## Students edition

Extract this entire ZIP. Keep the notebook, `lab05_support.py`, and `data` together.
Open `Lab05_Students.ipynb` in your existing Jupyter environment, then select
Restart Kernel and Run All. Python 3.10 or later is the intended environment; the release
was executed using Python 3.13.5.

The algorithm code uses the Python standard library. No NLTK resources, third-party
spellchecking libraries, live websites, or dataset downloads are required for the core lab.
When Jupyter is not installed, use a terminal in this folder:

```bash
python -m pip install -r requirements.txt
python -m jupyterlab
```

`Lab05_Students.html` is a standalone, read-only copy. Its mathematics is rendered as
inline SVG and works offline without loading fonts, scripts or content from a CDN.
Edit code and answers in the notebook, not the HTML.

This edition contains ten programming exercises, hints, tests, and five written-response spaces. The untouched notebook reports INCOMPLETE or BLOCKED until the exercises are completed. No reference implementations or teacher-only notes are bundled.

After changing a function, rerun its definition and tests. Corrector adapters cache results
for the fixed vocabulary; rerun their cell or restart the kernel after changing the
vocabulary or implementations. Always restart and run all before submission.

The included datasets are small authored instructional fixtures, not the original online
corpora. See `DATA_PROVENANCE.md` and the notebook's optional extension. The published
scores describe only this fixture. `VALIDATION.md` records the release checks and limits.
