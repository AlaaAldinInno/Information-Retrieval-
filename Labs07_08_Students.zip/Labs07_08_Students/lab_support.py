"""Display helpers, validation, and contract checks for the ML vector-space lab.

The exercises are implemented in the notebook. UnitTestEncoder is a test double,
not a pretrained model, and must never be used to report semantic-search results.
"""
from pathlib import Path
from numbers import Integral
import hashlib
import importlib.util
import json
from html import escape
import tempfile
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from IPython.display import HTML, display

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
OUTPUTS = ROOT / 'outputs'
MODEL_DIR = ROOT / 'models' / 'all-MiniLM-L6-v2'
MODEL_ID = 'sentence-transformers/all-MiniLM-L6-v2'
MODEL_REVISION = '1110a243fdf4706b3f48f1d95db1a4f5529b4d41'
CHECKS = {f'E{i}': 'NOT RUN' for i in range(1, 11)}
QUERIES = json.loads((DATA / 'queries.json').read_text(encoding='utf-8'))


def as_matrix(values):
    if np.iscomplexobj(values):
        raise ValueError('Use real-valued vectors.')
    result = np.array(values, dtype=float, copy=True)
    if result.ndim != 2 or result.shape[1] == 0:
        raise ValueError('Expected a 2-D matrix with at least one column.')
    if not np.isfinite(result).all():
        raise ValueError('Vector coordinates must be finite.')
    return result


def as_query(values, width):
    if np.iscomplexobj(values):
        raise ValueError('Use a real query vector.')
    q = np.array(values, dtype=float, copy=True)
    if q.ndim != 1 or q.size != width or not np.isfinite(q).all():
        raise ValueError(f'Expected a finite query vector of shape ({width},).')
    return q


def checked_k(k):
    if isinstance(k, (bool, np.bool_)) or not isinstance(k, Integral) or k < 0:
        raise ValueError('k must be a nonnegative integer, not a Boolean.')
    return int(k)


def checked_text(text):
    if not isinstance(text, str) or not text.strip():
        raise ValueError('Expected a nonempty text string.')
    return text.strip()


def checked_labels(relevances):
    a = np.asarray(relevances, dtype=float)
    if a.ndim != 1 or not np.isfinite(a).all() or not np.isin(a, [0, 1, 2]).all():
        raise ValueError('Relevance labels must be a 1-D sequence of 0, 1, or 2.')
    return a


def verify_corpus_file():
    manifest = json.loads((DATA / 'manifest.json').read_text(encoding='utf-8'))
    raw = (DATA / 'facts.txt').read_bytes()
    if hashlib.sha256(raw).hexdigest() != manifest['sha256']:
        raise ValueError('Corpus bytes changed. Rebuild vectors and judgments before use.')
    return manifest


def load_archived_run():
    verify_corpus_file()
    data = json.loads((DATA / 'archived_run.json').read_text(encoding='utf-8'))
    facts = (DATA / 'facts.txt').read_text(encoding='utf-8').splitlines()
    for hits in data['run'].values():
        for r, hit in enumerate(hits, 1):
            assert hit['rank'] == r and facts[hit['doc_id']] == hit['text']
            assert hit['score'] is None
    return data['run']


def try_load_local_encoder():
    """Only load a deliberately prepared local model; never download silently."""
    if not MODEL_DIR.is_dir():
        print('MODEL NOT PREPARED: run python prepare_model.py once, then restart this notebook.')
        return None
    if importlib.util.find_spec('sentence_transformers') is None:
        print('MODEL DEPENDENCY MISSING: install requirements-model.txt and restart the kernel.')
        return None
    try:
        from sentence_transformers import SentenceTransformer
        model = SentenceTransformer(str(MODEL_DIR), device='cpu', local_files_only=True)
    except (OSError, ImportError, ValueError, RuntimeError) as exc:
        print(f'MODEL LOAD FAILED: {type(exc).__name__}: {exc}')
        return None
    print('Local pretrained encoder loaded:', MODEL_ID)
    print('Embedding width:', model.get_sentence_embedding_dimension())
    return model


def live_ready(encoder):
    if encoder is None:
        print('PREPARATION REQUIRED: this cell needs the real pretrained encoder. '
              'Saved source results remain available below; they are not a fresh run.')
        return False
    return True


def run_check(name, check, requires=()):
    missing = [s for s in requires if CHECKS[s] != 'PASS']
    if missing:
        CHECKS[name] = 'BLOCKED'
        print(f'{name}: BLOCKED — finish '+', '.join(missing))
        return False
    try:
        check()
    except NotImplementedError:
        CHECKS[name] = 'INCOMPLETE'
        print(f'{name}: INCOMPLETE — fill the code gap, then rerun this check.')
        return False
    except Exception as exc:
        CHECKS[name] = 'FAIL'
        print(f'{name}: FAIL — {type(exc).__name__}: {exc}')
        return False
    CHECKS[name] = 'PASS'
    print(f'{name}: PASS')
    return True


def ready(*names):
    missing = [s for s in names if CHECKS[s] != 'PASS']
    if missing:
        print('BLOCKED — complete '+', '.join(missing))
        return False
    return True


def show_progress():
    display(pd.DataFrame({'exercise': list(CHECKS), 'contract check': list(CHECKS.values())}))


RESULT_CSS = """
<style>
.ir-panel{font:inherit;margin:1rem 0;border:1px solid #cbd5df;border-radius:8px;overflow:hidden;}
.ir-panel summary{padding:12px 16px;cursor:pointer;background:#f4f7fa;font-weight:600;}
.ir-caption{padding:8px 16px;font-size:.88rem;color:#425466;line-height:1.5;}
.ir-hit{padding:12px 16px;border-top:1px solid #e2e8f0;break-inside:avoid;}
.ir-meta{font-size:.82rem;color:#506579;margin-bottom:6px;font-family:monospace;}
.ir-text{line-height:1.65;overflow-wrap:anywhere;}
.ir-compare{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;}
@media(max-width:700px){.ir-compare{grid-template-columns:1fr;}}
</style>
"""


def result_panel(query, hits, title, score_label='cosine', open_panel=True):
    cards = []
    for r, h in enumerate(hits, 1):
        score = h.get('score')
        score_text = 'score not stored in source' if score is None else f'{score_label} = {float(score):.4f}'
        cards.append(f'<div class="ir-hit"><div class="ir-meta">Rank {r} · row ID {int(h["doc_id"])} · '
                     f'{escape(score_text)}</div><div class="ir-text">{escape(h["text"])}</div></div>')
    if not cards:
        cards.append('<div class="ir-hit">No results under this run’s retrieval policy.</div>')
    flag = ' open' if open_panel else ''
    return (f'<details class="ir-panel"{flag}><summary>{escape(query)} — {escape(title)}</summary>'
            + ''.join(cards) + '</details>')


def show_results(query, hits, title='Current run', score_label='cosine'):
    display(HTML(RESULT_CSS + result_panel(query, hits, title, score_label)))


def show_bucket(run, title='Current run', score_label='cosine'):
    display(HTML(RESULT_CSS + ''.join(result_panel(q, hits, title, score_label, i == 0)
                                     for i, (q, hits) in enumerate(run.items()))))


def compare_results(query, first, second, first_title, second_title):
    display(HTML(RESULT_CSS + '<div class="ir-compare">' +
                 result_panel(query, first, first_title) + result_panel(query, second, second_title)
                 + '</div>'))


def lexical_baseline(facts, queries, k=5):
    """Supplied optional comparison, not a substitute for the neural encoder."""
    from sklearn.feature_extraction.text import TfidfVectorizer
    k = checked_k(k)
    vectorizer = TfidfVectorizer(stop_words='english',
                               token_pattern=r'(?u)\b[a-zA-Z][a-zA-Z]+\b', norm='l2')
    D = vectorizer.fit_transform(facts)
    result = {}
    for query in queries:
        Q = vectorizer.transform([query])
        scores = (D @ Q.T).toarray().ravel()
        ids = sorted((i for i in range(len(facts)) if scores[i] > 0),
                     key=lambda i: (-scores[i], i))[:k]
        result[query] = [{'rank': r, 'doc_id': i, 'score': float(scores[i]), 'text': facts[i]}
                         for r, i in enumerate(ids, 1)]
    return result


def save_run(run, name='live_run.json', model=None):
    OUTPUTS.mkdir(exist_ok=True)
    payload = {'kind': 'fresh cosine run', 'model_id': MODEL_ID,
               'model_revision': MODEL_REVISION,
               'corpus_sha256': verify_corpus_file()['sha256'], 'run': run}
    if model is not None:
        payload['embedding_width'] = int(model.get_sentence_embedding_dimension())
        payload['max_sequence_length'] = int(model.max_seq_length)
    path = OUTPUTS / name
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding='utf-8')
    return path


def expanded_judgment_template(runs, existing, facts):
    """Pool every run before judging; retain completed labels instead of overwriting."""
    rows = existing.copy()
    known = set(zip(rows['query'], rows['doc_id']))
    extra = []
    for run in runs:
        for query, hits in run.items():
            for hit in hits:
                key = query, int(hit['doc_id'])
                if key not in known:
                    known.add(key)
                    extra.append({'query': query, 'doc_id': key[1], 'text': facts[key[1]],
                                  'relevance': '', 'reason': ''})
    if extra:
        rows = pd.concat([rows, pd.DataFrame(extra)], ignore_index=True)
    order = {q: i for i, q in enumerate(QUERIES)}
    return rows.assign(_q=rows['query'].map(order)).sort_values(['_q','doc_id']).drop(columns='_q')


def plot_score_bars(query, hits):
    if not hits or any(h['score'] is None for h in hits):
        print('No numeric score plot: no scores are available for this run.')
        return
    fig, ax = plt.subplots(figsize=(8, 3.8))
    labels = [f"#{r} · row {h['doc_id']}" for r,h in enumerate(hits,1)]
    ax.barh(labels, [h['score'] for h in hits]); ax.invert_yaxis()
    ax.set(xlabel='Cosine similarity', title=f'Retrieved score profile: {query}')
    fig.tight_layout(); plt.show()


def plot_discount_trace(labels):
    grades = checked_labels(labels)
    positions = np.arange(1,len(grades)+1)
    terms = (2.0**grades-1)/np.log2(positions+1)
    fig, ax = plt.subplots(figsize=(8, 3.5))
    ax.bar(positions, terms)
    ax.set(xlabel='Rank (one-based)', ylabel='Discounted gain', title='Worked DCG contributions')
    ax.set_xticks(positions); fig.tight_layout(); plt.show()
    return pd.DataFrame({'rank': positions, 'relevance': grades.astype(int),
                         'gain': 2**grades-1, 'discounted_gain': terms, 'cumulative_DCG': np.cumsum(terms)})


def plot_evaluation(reports):
    if not reports:
        return
    queries = list(next(iter(reports.values()))['query'])
    fig, ax = plt.subplots(figsize=(9, 4))
    n = len(reports); width = .8/n; x = np.arange(len(queries))
    for i, (label, frame) in enumerate(reports.items()):
        values = frame.set_index('query').loc[queries, 'ndcg'].to_numpy()
        ax.bar(x+(i-(n-1)/2)*width, values, width, label=label)
    ax.set_xticks(x, queries, rotation=15)
    ax.set(ylabel='Pool-relative nDCG@5', ylim=(0,1.05), title='Ranking order under the same teaching judgments')
    ax.legend(); fig.tight_layout(); plt.show()


class UnitTestEncoder:
    """Small deterministic test fixture. Not a sentence model or semantic evidence."""
    def __init__(self):
        self.calls = []
    def get_sentence_embedding_dimension(self):
        return 3
    def encode(self, texts, **kwargs):
        if isinstance(texts, str):
            raise AssertionError('Pass a list of strings to keep the matrix shape explicit.')
        self.calls.append((list(texts), dict(kwargs)))
        dictionary = {'alpha': [3,0,0], 'beta': [0,4,0], 'alpha beta': [3,4,0], 'gamma': [0,0,5]}
        return np.asarray([dictionary.get(t, [len(t),1,2]) for t in texts], dtype=float).reshape(-1,3)


def must_raise(fn, exception=ValueError):
    try:
        fn()
    except exception:
        return
    raise AssertionError(f'Expected {exception.__name__}.')


def check_read(fn):
    with tempfile.TemporaryDirectory() as tmp:
        path = Path(tmp)/'facts.txt'
        path.write_text(' 1. Alpha. \n\n1. Beta.\n  \n',encoding='utf-8')
        assert fn(path) == ['1. Alpha.', '1. Beta.']
        path.write_text('\n  \n',encoding='utf-8')
        assert fn(path) == []
    facts = fn(DATA/'facts.txt')
    assert len(facts)==159 and 'our lovely little planet' in facts[0]


def check_embed(fn):
    enc = UnitTestEncoder()
    a = fn('  alpha  ',enc)
    assert isinstance(a,np.ndarray) and a.shape==(3,) and np.allclose(a,[3,0,0])
    assert np.allclose(fn('alpha',enc),a)
    assert fn('gamma',enc).shape==a.shape
    for invalid in ['', '   ', None, 7]: must_raise(lambda: fn(invalid,enc))
    assert all(isinstance(c[0],list) for c in enc.calls)


def check_corpus(fn):
    enc = UnitTestEncoder()
    X = fn(['alpha','beta','alpha beta'],enc,batch_size=2)
    assert X.shape==(3,3) and np.allclose(X,[[3,0,0],[0,4,0],[3,4,0]])
    assert len(enc.calls)==1, 'Use one batched encode call, not one call per document.'
    assert enc.calls[0][1].get('batch_size')==2
    assert fn([],enc).shape==(0,3)
    must_raise(lambda: fn([''],enc))
    must_raise(lambda: fn(['alpha'],enc,batch_size=0))


def check_norm(fn):
    X = np.array([[3.,4.],[-3.,4.],[0.,0.]])
    original = X.copy(); Y=fn(X)
    assert np.allclose(Y,[[.6,.8],[-.6,.8],[0,0]])
    assert np.array_equal(X,original)
    assert fn(np.empty((0,2))).shape==(0,2)
    assert np.allclose(fn(Y),Y)
    must_raise(lambda: fn([[np.nan,0]]))


def check_cosine(fn):
    X = np.array([[1.,0.],[100.,100.],[-2.,0.],[0.,0.]])
    expected=np.array([1,1/np.sqrt(2),-1,0])
    assert np.allclose(fn([1,0],X),expected)
    assert np.allclose(fn([7,0],X),expected)
    assert np.allclose(fn([0,0],X),0)
    assert fn([1,0],np.empty((0,2))).shape==(0,)
    must_raise(lambda: fn([1,2,3],X))


def check_topk(fn):
    X = np.array([[1.,0.],[2.,0.],[0.,0.],[-1.,0.],[0.,1.]])
    assert fn([1,0],X,k=9)==[0,1,4,3], 'Skip zero rows, not negative similarities.'
    assert fn([1,0],X,k=0)==[]
    assert fn([0,0],X,k=3)==[]
    assert fn([1,0],np.empty((0,2)),k=3)==[]
    for k in [-1,1.5,True]: must_raise(lambda: fn([1,0],X,k=k))


def check_search(fn):
    enc=UnitTestEncoder(); texts=['alpha','beta','alpha beta']; X=np.array([[3,0,0],[0,4,0],[3,4,0]])
    run=fn(['alpha','beta'],texts,X,enc,k=2)
    assert list(run)==['alpha','beta']
    assert [h['doc_id'] for h in run['alpha']]==[0,2]
    assert [h['doc_id'] for h in run['beta']]==[1,2]
    for hits in run.values():
        for rank,h in enumerate(hits,1):
            assert h['rank']==rank and h['text']==texts[h['doc_id']]
            assert np.isfinite(h['score'])
    must_raise(lambda: fn(['alpha'],texts,X[:2],enc))
    must_raise(lambda: fn(['alpha','alpha'],texts,X,enc))


def check_qrels(fn):
    data=pd.DataFrame({'query':['a','a','b'],'doc_id':[0,1,0],'relevance':[2,0,1]})
    assert fn(data)=={'a':{0:2,1:0},'b':{0:1}}
    for value in [np.nan,'',-1,3,.5]:
        bad=data.copy(); bad['relevance']=bad['relevance'].astype(object); bad.loc[0,'relevance']=value
        must_raise(lambda: fn(bad))
    must_raise(lambda: fn(pd.concat([data,data.iloc[[0]]])))
    bad=data.copy(); bad.loc[0,'doc_id']=-1; must_raise(lambda: fn(bad))
    assert fn(data.iloc[:0])=={}


def check_dcg(fn):
    assert np.isclose(fn([2,0,1],k=3),3.5)
    assert np.isclose(fn([2,1],k=5),3+1/np.log2(3))
    assert fn([],k=5)==0 and fn([2,1],k=0)==0
    assert fn([0,0],k=5)==0
    assert fn([2,0,0],k=3)>fn([0,0,2],k=3)
    must_raise(lambda: fn([np.nan]))
    must_raise(lambda: fn([3]))
    must_raise(lambda: fn([1],k=-2))


def check_evaluation(fn):
    run={'q':[{'doc_id':1},{'doc_id':2}], 'empty':[]}
    qrels={'q':{0:2,1:1,2:0}, 'empty':{0:0}}
    rows=fn(run,qrels,k=2); assert list(rows['query'])==['q','empty']
    a=rows.iloc[0]; assert np.isclose(a['dcg'],1.)
    assert np.isclose(a['idcg'],3+1/np.log2(3))
    assert np.isclose(a['ndcg'],1/a['idcg'])
    assert rows.iloc[1]['ndcg']==0
    must_raise(lambda: fn({'q':[{'doc_id':8}]},qrels))
    must_raise(lambda: fn({'q':[{'doc_id':1},{'doc_id':1}]},qrels))
    must_raise(lambda: fn({'missing':[]},qrels))
    assert fn({},{}).empty
