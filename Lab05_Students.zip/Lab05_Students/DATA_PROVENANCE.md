# Data provenance and experiment scope

The supplied source was `05 - Spellchecking solution.ipynb.txt`. It contains the lab
notebook, but not the external facts file or the complete GitHub Typo Corpus.

## Bundled, authored instructional fixtures

- `facts_lab.txt`: 12 short retrieval documents, not a version of the external facts collection.
- `training_text.txt`: 52 sentences; the only source of correction-vocabulary frequencies.
- `typos_dev.csv`: 8 development pairs.
- `typos_test.csv`: 20 test pairs, including two real-word errors and two unknown targets.
- `clean_controls.txt`: 12 correctly supplied words/identifiers; correctness is stipulated
  for this controlled experiment, including the unfamiliar identifiers.
- `github_schema_fixture.jsonl`: authored records for validating the original corpus schema.
  These records are not copied from real repositories.

The fixture is designed to make method behaviour visible, not to estimate performance
on natural user queries. Its development and test source tokens are disjoint. Frequencies
come exclusively from the independent training file. No original benchmark score is reused.

## Original external data retained as optional routes

Facts location from the supplied notebook:
https://raw.githubusercontent.com/hsu-ai-course/hsu.ai/master/code/datasets/nlp/facts.txt

GitHub Typo Corpus (v1.0.0), maintainers and download instructions:
https://github.com/mhagiwara/github-typo-corpus

Paper: Masato Hagiwara and Masato Mita, “GitHub Typo Corpus: A Large-Scale Multilingual
Dataset of Misspellings and Grammatical Errors” (2019): https://arxiv.org/abs/1911.12893

Neither external corpus is bundled. Download access and repository-specific reuse terms
remain the user's responsibility. The optional stream loader accepts local JSONL and
gzip-compressed JSONL files. Full-corpus loading and benchmark reproduction were not run.
