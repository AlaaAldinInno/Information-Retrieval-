# Labs 07–08 · Vector Space Models with Machine Learning

## Student workbook

This matched workbook combines the overlapping solution and exercise notebooks supplied for Labs 07–08. It retains the original facts collection, sentence-embedding/search task, all seven queries, all 35 saved query-bucket results, and the relevance-assessment/DCG activity. `SOURCE_MAP.md` documents the changes and additions.

## Open the lab

Extract the full ZIP. Keep all files together. Open **Labs07_08_Students.ipynb** in JupyterLab for the editable lab, or **Labs07_08_Students.html** for the offline reading copy. The HTML has pre-rendered equations, result displays and recorded plots; it cannot execute Python.

Use a fresh Python 3.11 or 3.12 environment, then run:

```bash
python -m pip install -r requirements.txt
jupyter lab
```

The notebook can display authentic saved results and run programming/metric checks with those dependencies. It does not silently replace the pretrained encoder with keyword search or a synthetic vector generator.

## Prepare the real neural model once

The weights are not in the ZIP. On a connected machine, run:

```bash
python -m pip install -r requirements-model.txt
python prepare_model.py
```

This prepares a fixed snapshot of `sentence-transformers/all-MiniLM-L6-v2` in `models/all-MiniLM-L6-v2/`. It then verifies a local-only reload, finite 384-dimensional outputs, and repeatability for identical text. Restart the notebook kernel afterward and Run All. The saved local folder can be used offline on machines with the same compatible model dependencies.

The model preparation and live neural inference were not executable in the document-building environment. They are deliberately labeled as requiring preparation; no fresh model results are claimed. The supplied source's stored outputs came from its older RoBERTa/spaCy workflow, not from a fresh MiniLM run. See `VALIDATION.md` for the exact verified scope.

## Contents

- `Labs07_08_Students.ipynb` and `Labs07_08_Students.html`: editable workbook and reading copy.
- `lab_support.py`: validators, supplied displays, optional TF-IDF comparison and contract checks.
- `prepare_model.py`: explicit one-time pretrained-model setup and local reload check.
- `data/facts.txt`, `queries.json`, `archived_run.json`: original corpus/query set and authentic saved rankings.
- `data/judgments_template.csv`, `intents.json`: blank evaluation worksheet and stated relevance criteria.
- `outputs/`: destination for your generated run and judgment worksheet; created if needed.
- `SOURCE_MAP.md`, `VALIDATION.md`, `data/README.md`: adaptation and provenance records.

Implement the ten code gaps using the documentation immediately above each one. Write your own relevance labels in `outputs/my_judgments.csv`; do not fill missing labels with zero. The package does not contain teacher-only implementations or suggested labels.

## Runtime behavior

An unfilled function reports INCOMPLETE, and dependent steps report BLOCKED. PREPARATION REQUIRED refers specifically to the missing real encoder. These are distinct states. A passing programming check is not a semantic-quality evaluation. Ranking scores, relevance judgments and corpus truth are different concepts.

The result displays contain actual retrieved passage text, not substitute illustrations. The optional TF-IDF baseline is labeled as lexical. The archive never receives invented numeric scores. Original source passages include unverified claims and must not be treated as factual or professional advice.

To evaluate a fresh run, expand the judgment pool first. The notebook writes `judgments_expanded.csv` rather than overwriting an existing worksheet. Review/complete it and use the same final pool for every compared system. Blank judgments are errors, not irrelevant labels.
