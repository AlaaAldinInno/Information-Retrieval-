# Lab 05 release validation

## Execution

The teacher notebook was executed from a fresh Python 3.13.5 kernel. All ten exercise
checks and the integration check passed (11/11); the optional loader's schema-fixture
assertions also passed. No notebook error outputs were produced.

The untouched student notebook was executed separately. It completed with six
INCOMPLETE exercise checks and five BLOCKED checks, including integration. These are
intentional scaffold states, not successful exercise completion. A private verification
copy, with only the ten exercise cells filled using the reference implementations,
passed all eleven checks. That completed student copy is not distributed.

## Independent algorithm checks

- 1,600 OSA string pairs matched RapidFuzz's OSA distance implementation.
- 795 wildcard cases across k = 1, 2, 3, 4, and 7 matched direct full-vocabulary pattern
  matching and direct document retrieval.
- 40 one-edit neighbourhoods matched a separately written edit enumerator.
- 300 Soundex cases matched a separate translate-and-run-collapse implementation of
  the specified textbook variant.
- 200 k-gram ranking cases matched a full-vocabulary overlap/similarity calculation.

Total: 2,935 reference or brute-force algorithm comparisons. Randomized portions used
seed 5005. RapidFuzz is only a release-validation tool; it is not a student dependency.
The tests are evidence for the covered inputs, not a proof for all possible inputs.

The optional original-corpus loader was checked for plain/gzip agreement, zero/one-case
limits, malformed-JSON line reporting, single-token extraction, and stable repository
partitioning. It was not run on the complete external corpus.

## Rendering and distribution

Both notebooks were converted using the notebook Markdown renderer, syntax-highlighted,
and rendered to standalone HTML with inline SVG mathematics. Each contains 78 rendered
math expressions, with zero reported TeX errors and zero mathematical error nodes.
No external scripts, stylesheets, images, fonts, or remote requests are needed to open
the reading copies. Font files are not distributed.

Rendered page captures for both editions were inspected across their full length;
worked equations, matrices, tables, code blocks, and student response spaces were also
checked in detail. Automated layout checks at 1440-pixel and 768-pixel viewport widths
found no horizontal overflow. Internal navigation links resolved. This validates the
included HTML reading copies, not every third-party notebook frontend or print setting.

The student package contains ten intentional exercise cells and five written-response
spaces. It does not contain reference implementation cells, teacher discussion answers,
or teacher-only notes. Both notebooks pass the notebook-format validator.

## Scope limits

The data are authored classroom fixtures. Their correction scores are not a reproduction
of the original full-corpus experiment and do not establish a general ordering of methods.
The original facts download and the full GitHub Typo Corpus were not fetched or evaluated.
The core lab runs offline after a Jupyter environment is installed. Only Python 3.13.5
was used for execution validation; Python 3.10+ is the intended language-version range.
